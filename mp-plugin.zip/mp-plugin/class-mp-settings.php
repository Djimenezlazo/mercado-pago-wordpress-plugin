<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class MP_Settings {

    public static function init() {
        add_filter( 'woocommerce_get_settings_pages', array( __CLASS__, 'add_settings_page' ) );
    }

    public static function add_settings_page( $settings ) {
        $settings[] = include( plugin_dir_path( __FILE__ ) . 'class-mp-settings-page.php' );
        return $settings;
    }

}

MP_Settings::init();

