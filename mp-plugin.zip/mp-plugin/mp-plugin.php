<?php
/**
 * Plugin Name: MP Plugin
 * Description: Integración de Mercado Pago con WooCommerce.
 * Version: 1.0
 * Author: Tu Nombre
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Evitar acceso directo
}

// Verificar si WooCommerce está activo
add_action( 'plugins_loaded', 'mp_plugin_init', 11 );

function mp_plugin_init() {
    if ( class_exists( 'WooCommerce' ) ) {
        // Cargar las clases del plugin
        require_once plugin_dir_path( __FILE__ ) . 'class-mp-gateway.php';
        require_once plugin_dir_path( __FILE__ ) . 'class-mp-settings.php';

        // Registrar el gateway de pago
        add_filter( 'woocommerce_payment_gateways', 'mp_register_gateway' );
    } else {
        // Notificar que WooCommerce no está activo
        add_action( 'admin_notices', 'mp_woocommerce_inactive_notice' );
    }
}

function mp_register_gateway( $methods ) {
    $methods[] = 'MP_Gateway'; // Registrar el gateway
    return $methods;
}

function mp_woocommerce_inactive_notice() {
    echo '<div class="error"><p>WooCommerce debe estar activo para usar el plugin MP Gateway.</p></div>';
}

// Hook de activación del plugin
register_activation_hook( __FILE__, 'mp_plugin_activation' );

function mp_plugin_activation() {
    if ( ! class_exists( 'WooCommerce' ) ) {
        wp_die( 'WooCommerce debe estar activo para activar este plugin.' );
    }
}
