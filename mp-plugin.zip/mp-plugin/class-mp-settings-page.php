<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit; // Evitar acceso directo
}

class MP_Settings_Page {
    public function __construct() {
        // Registrar la página en WordPress
        add_action( 'admin_menu', array( $this, 'add_settings_page' ) );
    }

    public function add_settings_page() {
        add_menu_page(
            'Configuración de Mercado Pago',
            'Configuración de Mercado Pago',
            'manage_options',
            'mp-settings',
            array( $this, 'render_settings_page' ),
            '',
            null // No icono
        );
    }

    public function render_settings_page() {
        ?>
        <div class="wrap">
            <h1>Configuración de Mercado Pago</h1>
            <form method="post" action="options.php">
                <?php
                settings_fields( 'mp_settings_group' );
                do_settings_sections( 'mp-settings' );
                submit_button();
                ?>
            </form>
        </div>
        <?php
    }
}
