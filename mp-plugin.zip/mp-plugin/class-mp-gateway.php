<?php

if ( ! defined( 'ABSPATH' ) ) {
exit; // Salir si se accede directamente.
}

require_once plugin_dir_path( __FILE__ ) . 'vendor/autoload.php';

class MP_Gateway extends WC_Payment_Gateway {

public $client_id;
public $client_secret;
public $sandbox_mode;

public function __construct() {
    $this->id                 = 'mp_gateway';
    $this->method_title       = 'Mercado Pago';
    $this->method_description = 'Integra Mercado Pago como método de pago en tu tienda.';
    $this->has_fields         = true;

    // Cargar configuración
    $this->init_form_fields();
    $this->init_settings();

    // Guardar valores de configuración
    $this->title         = $this->get_option( 'title' );
    $this->description   = $this->get_option( 'description' );
    $this->enabled       = $this->get_option( 'enabled' );
    $this->client_id     = $this->get_option( 'client_id' );
    $this->client_secret = $this->get_option( 'client_secret' );
    $this->sandbox_mode  = $this->get_option( 'sandbox_mode' ) === 'yes';

    // Guardar los ajustes
    add_action( 'woocommerce_update_options_payment_gateways_' . $this->id, array( $this, 'process_admin_options' ) );
}

public function init_form_fields() {
    $this->form_fields = array(
        'enabled' => array(
            'title'   => __( 'Habilitar/Deshabilitar', 'mp-plugin' ),
            'type'    => 'checkbox',
            'label'   => __( 'Habilitar Mercado Pago', 'mp-plugin' ),
            'default' => 'yes',
        ),
        'sandbox_mode' => array(
            'title'   => __( 'Modo Sandbox', 'mp-plugin' ),
            'type'    => 'checkbox',
            'label'   => __( 'Habilitar modo sandbox para pruebas', 'mp-plugin' ),
            'default' => 'no',
        ),
        'sandbox_access_token' => array(
		    'title'       => __( 'Sandbox Access Token', 'mp-plugin' ),
		    'type'        => 'text',
		    'default'     => '',
		    'desc_tip'    => true,
		),
		    'title' => array(
            'title'       => __( 'Título', 'mp-plugin' ),
            'type'        => 'text',
            'default'     => __( 'Pagar con Mercado Pago', 'mp-plugin' ),
            'desc_tip'    => true,
        ),
        'description' => array(
            'title'       => __( 'Descripción', 'mp-plugin' ),
            'type'        => 'textarea',
            'default'     => __( 'Pague de manera fácil y segura con Mercado Pago.', 'mp-plugin' ),
            'desc_tip'    => true,
        ),
        'mp_success_url' => array(
            'title'       => __( 'URL de Éxito', 'mp-plugin' ),
            'type'        => 'text',
            'default'     => '',
            'desc_tip'    => true,
        ),
        'mp_failure_url' => array(
            'title'       => __( 'URL de Error', 'mp-plugin' ),
            'type'        => 'text',
            'default'     => '',
            'desc_tip'    => true,
        ),
        'mp_pending_url' => array(
            'title'       => __( 'URL de Pendiente', 'mp-plugin' ),
            'type'        => 'text',
            'default'     => '',
            'desc_tip'    => true,
        ),
        'client_id' => array(
            'title'       => __( 'Client ID', 'mp-plugin' ),
            'type'        => 'text',
            'default'     => '',
            'desc_tip'    => true,
        ),
        'client_secret' => array(
            'title'       => __( 'Client Secret', 'mp-plugin' ),
            'type'        => 'text',
            'default'     => '',
            'desc_tip'    => true,
        ),
    );
}

public function process_payment($order_id) {
    $order = wc_get_order($order_id);
    $items = $order->get_items();

    if (empty($items)) {
        return array('result' => 'failure', 'message' => __('Este pedido no contiene productos.', 'mp-plugin'));
    }

    $client_id = sanitize_text_field($this->get_option('client_id'));
    $client_secret = sanitize_text_field($this->get_option('client_secret'));
    $sandbox_access_token = sanitize_text_field($this->get_option('sandbox_access_token'));
    $success_url = esc_url_raw($this->get_option('mp_success_url'));
    $failure_url = esc_url_raw($this->get_option('mp_failure_url'));
    $pending_url = esc_url_raw($this->get_option('mp_pending_url'));

    if (empty($success_url) || empty($failure_url) || empty($pending_url)) {
        return array('result' => 'failure', 'message' => __('Las URLs de redirección no están configuradas.', 'mp-plugin'));
    }

    if ($this->sandbox_mode) {
        MercadoPago\SDK::setAccessToken($sandbox_access_token); // Reemplaza con tu token
    } else {
        MercadoPago\SDK::setClientId($client_id);
        MercadoPago\SDK::setClientSecret($client_secret);
    }

    $preference = new MercadoPago\Preference();
    $items_array = [];

    foreach ($items as $order_item) {
        if (empty($order_item->get_name()) || $order_item->get_quantity() <= 0 || $order_item->get_total() <= 0) {
            error_log('Ítem inválido en el pedido: ' . print_r($order_item, true));
            return array('result' => 'failure', 'message' => __('Uno o más productos no son válidos.', 'mp-plugin'));
        }

        $item = new MercadoPago\Item();
        $item->id = $order_item->get_product_id();
        $item->title = sanitize_text_field($order_item->get_name());
        $item->quantity = $order_item->get_quantity();
        $item->unit_price = $order_item->get_total() / $order_item->get_quantity();
        $items_array[] = $item;
    }

    $preference->items = $items_array;
    $preference->back_urls = [
        "success" => $success_url,
        "failure" => $failure_url,
        "pending" => $pending_url,
    ];
    $preference->auto_return = "approved";

    try {
        $preference->save();
        error_log('Preferencia creada: ' . print_r($preference, true)); // Log de la preferencia
        return array('result' => 'success', 'redirect' => $preference->init_point);
    } catch (Exception $e) {
        error_log('Error en Mercado Pago: ' . $e->getMessage()); // Log del error
        return array('result' => 'failure', 'message' => __('Ocurrió un error al procesar el pago.', 'mp-plugin'));
    }
}
}
